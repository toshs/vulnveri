/* A stub stdbool.h for VC2012 or earlier.
 * ActivePerl 5.20+ requires stdbool.h but VC2012 doesn't have it. */
#define bool char
